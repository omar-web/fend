dynamic nav with dynamic active classes
red border added to sections when active

responsive design header content becomes centered on smaller screens
